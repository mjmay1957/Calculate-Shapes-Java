
public class Rectangle extends Shape 
{

	private String sName;

	static double volume;
	static double area;
	static double length; 
	static double width;
	static double height;
	static double areaRnd;
	static double volumeRnd;
	
	
	// Constructor
	public Rectangle(String sn) 
	{
		super(sn);
		sName=sn;
	}
		
	public void setshapeName(String sn)
	{
		sName = sn;
	}

		
		
	// Set the length and width to be used in rectangle class from the length and width entered on screen
	public void setRectangleVar(double l, double w, double h)
	{
		length = l;
		width = w;
		height = h;
	}
		
					
	// Rectangle Method accepts length and width of a rectangle and returns the area  
	public double getArea()
	{ 
		area = (length * width);
		areaRnd = Math.round(area * 100)/ 100.0;
		
	return areaRnd;
	}


	// Rectangle Method accepts length width of rectangle and returns the volume  
	public double getVolume() 
	{
		volume = (length * width * height);
		volumeRnd = Math.round(volume * 100)/ 100.0;
			
	return volumeRnd;
	}
	
}
