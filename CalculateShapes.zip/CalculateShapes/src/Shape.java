
public abstract class Shape 
{

	protected String shapeName;
	
	// Constructor
	public Shape (String sn)
	{
		shapeName=sn;
	}
	
	// Get method to return shapeName
	public String getName()
	{
		return shapeName;
	}
		
	
	// Abstract method that will be extended to return the Area that the subclasses of Circle, 
	// Square, Rectangle and Triangle calculated
	
	public abstract double getArea();
	
	
	// Abstract method that will be extended to return the Volume that the subclasses of Circle, 
		// Square, Rectangle and Triangle calculated
	
	public abstract double getVolume();


}
