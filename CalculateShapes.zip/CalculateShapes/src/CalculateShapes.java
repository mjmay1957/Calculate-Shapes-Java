import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Component;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;

import java.awt.Panel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.*;


public class CalculateShapes 
{

	private JFrame frame;
	private JTextField txtFldOptionM;
	private JTextField txtFldRadiusC;
	private JTextField txtFldWidthR;
	private JTextField txtFldLengthR;
	private JTextField txtFldHeightR;
	private JTextField txtFldHeightT;
	private JTextField txtFldBaseT;
	private JTextField txtFldLengthT;
	private JTextField txtFldSideS;
	
	ImageIcon Backgrd = new ImageIcon("C:/Users/marga/workspace/CalculateShapes/src/background1.jpg");
	
	double side;	
	double base;
	double height;
	double radius;
	double length; 
	double width;
	double area;
	double areaRnd;
	double volumeRnd;
	String areaString;
	String sName;
	
	 
	
	
	
	/**
	 * Launch the application.   ********************* MAIN METHOD *****************
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculateShapes window = new CalculateShapes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CalculateShapes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
	
		frame = new JFrame();
		frame.setBounds(100, 100, 944, 537);
		// Set to maximized height and width.
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		
		// get the screen size as a java dimension and then set screen accordingly
		//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//frame.setSize(screenSize.width, screenSize.height);
		 
		/* get 2/3 of the height, and 2/3 of the width
		int height = screenSize.height;
		int width = screenSize.width;
		Set the jframe height and width
		frame.setSize(screenSize.width * 2/3, screenSize.height * 2/3); 
		frame.setSize(screenSize.width/2, screenSize.height/2);
		frame.setPreferredSize(new Dimension(width, height));
		*/

		//frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		
		// Create new object classes from external classes Circle, Square, Rectangle and Triangle  
				// Establish Constructor by passing variables
				
				Circle circleObj = new Circle(sName);
				Square squareObj = new Square(sName);
				Rectangle rectangleObj = new Rectangle(sName);
				Triangle triangleObj = new Triangle(sName);

						
		// ************************** DECLARE JPANELS *************************************
				
		JPanel panelMain = new JPanel();
		panelMain.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelMain, "name_160839995418535");
		panelMain.setLayout(null);
		
		Panel panelCircle = new Panel();
		panelCircle.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelCircle, "name_167107823686084");
		panelCircle.setLayout(null);
		
		JPanel panelSquare = new JPanel();
		panelSquare.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelSquare, "name_167475960510363");
		panelSquare.setLayout(null);
		
		JPanel panelRectangle = new JPanel();
		panelRectangle.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelRectangle, "name_167744644747651");
		panelRectangle.setLayout(null);
		
		JPanel panelTriangle = new JPanel();
		panelTriangle.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelTriangle, "name_167856787938426");
		panelTriangle.setLayout(null);
				
		
		// ************************** MAIN MENU *************************************
		
		JLabel lblMHeading = new JLabel("**** SHAPE CALCULATOR ****");
		lblMHeading.setForeground(new Color(0, 0, 255));
		lblMHeading.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblMHeading.setBounds(307, 75, 327, 20);
		panelMain.add(lblMHeading);
		
		JLabel lblCircle = new JLabel("1. Circle ");
		lblCircle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCircle.setForeground(new Color(0, 0, 255));
		lblCircle.setBounds(397, 141, 78, 20);
		panelMain.add(lblCircle);
		
		JLabel lblSquare = new JLabel("2. Square");
		lblSquare.setForeground(new Color(0, 0, 255));
		lblSquare.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSquare.setBounds(397, 177, 94, 20);
		panelMain.add(lblSquare);
		
		JLabel lblRectangle = new JLabel("3. Rectangle");
		lblRectangle.setForeground(new Color(0, 0, 255));
		lblRectangle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRectangle.setBounds(397, 213, 126, 20);
		panelMain.add(lblRectangle);
		
		JLabel lblTriangle = new JLabel("4. Triangle");
		lblTriangle.setForeground(new Color(0, 0, 255));
		lblTriangle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTriangle.setBounds(397, 249, 105, 20);
		panelMain.add(lblTriangle);
		
		JLabel lblExit = new JLabel("5. Exit");
		lblExit.setForeground(new Color(0, 0, 255));
		lblExit.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExit.setBounds(397, 287, 78, 20);
		panelMain.add(lblExit);
		
		JLabel lblOptionM = new JLabel("Option:");
		lblOptionM.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblOptionM.setForeground(new Color(0, 0, 255));
		lblOptionM.setBounds(307, 332, 69, 20);
		panelMain.add(lblOptionM);
		
		JLabel lblErrMsgM = new JLabel(" ");
		lblErrMsgM.setForeground(new Color(204, 0, 0));
		lblErrMsgM.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgM.setBounds(35, 433, 838, 20);
		panelMain.add(lblErrMsgM);
		
		txtFldOptionM = new JTextField();
		txtFldOptionM.setBackground(new Color(255, 255, 255));
		txtFldOptionM.setForeground(Color.BLUE);
		txtFldOptionM.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldOptionM.setBounds(407, 330, 69, 26);
		panelMain.add(txtFldOptionM);
		txtFldOptionM.setColumns(10);
				
		JButton btnMContinue = new JButton("Continue");
		btnMContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnMContinue.setForeground(new Color(255, 255, 255));
		btnMContinue.setBackground(new Color(0, 102, 0));
		btnMContinue.setBounds(283, 388, 135, 29);
		panelMain.add(btnMContinue);
		btnMContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String option = txtFldOptionM.getText();
				try
				{ 
					int opt = Integer.parseInt(option);
					if ((opt < 1) || (opt > 5))
					{
						lblErrMsgM.setText("Invalid Option entered, Please re-enter (1-5)");
						panelMain.setVisible(true);
						txtFldOptionM.requestFocusInWindow();
						txtFldOptionM.setCaretPosition(0);
					} else
					{	
								
						switch(opt)
						{
						case 1:
							// Circle Radius for Area and Volume
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelSquare.setVisible(false);
							panelRectangle.setVisible(false);
							panelTriangle.setVisible(false);
							panelCircle.setVisible(true);
							txtFldRadiusC.setText(null);
							//txtFldRadiusC.setCaretPosition(0);
							txtFldRadiusC.requestFocusInWindow();
							break;
						case 2:
							// Square Side for Area and Volume
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelRectangle.setVisible(false);
							panelTriangle.setVisible(false);
							panelCircle.setVisible(false);
							panelSquare.setVisible(true);
							txtFldSideS.setText(null);
							//txtFldSideS.setCaretPosition(0);
							txtFldSideS.requestFocusInWindow();
							break;
						case 3:
							// Rectangle Side for Area and Volume
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelSquare.setVisible(false);
							panelTriangle.setVisible(false);
							panelCircle.setVisible(false);
							panelRectangle.setVisible(true);
							txtFldLengthR.setText(null);
							txtFldWidthR.setText(null);
							//txtFldLengthR.setCaretPosition(0);
							txtFldLengthR.requestFocusInWindow();
							break;
						case 4:
							// Rectangle Side for Area and Volume
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelSquare.setVisible(false);
							panelRectangle.setVisible(false);
							panelCircle.setVisible(false);
							panelTriangle.setVisible(true);
							txtFldBaseT.setText(null);
							txtFldHeightT.setText(null);
							//txtFldBaseT.setCaretPosition(0);
							txtFldBaseT.requestFocusInWindow();
							break;
						case 5:
							// Quit
							lblErrMsgM.setText(null);
							txtFldOptionM.setText(null);
							panelMain.setVisible(false);
							System.exit(0);
							break;
						default:
							lblErrMsgM.setText("Invalid Option entered, Please re-enter (1-5)");
					    	panelMain.setVisible(true);
							txtFldOptionM.requestFocusInWindow();
							txtFldOptionM.setCaretPosition(0);				
						} // END OF SWITCH
				
					} // END OF IF-ELSE FOR INVALID OPTION
				}
			    catch(NumberFormatException e1)
				{
			    	lblErrMsgM.setText("Option must be a numeric value");
			    	panelMain.setVisible(true);
					txtFldOptionM.requestFocusInWindow();
					txtFldOptionM.setCaretPosition(0);
				}	
					
			} // END OF ACTIONPERFORMED
	
		
		});
		
		JButton btnMQuit = new JButton("Quit");
		btnMQuit.setForeground(Color.WHITE);
		btnMQuit.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnMQuit.setBackground(new Color(204, 0, 0));
		btnMQuit.setBounds(519, 388, 135, 29);
		panelMain.add(btnMQuit);
		btnMQuit.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				lblErrMsgM.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(false);
				System.exit(0);
			}
		});
		
		
		JLabel lblBackgroundImageM = new JLabel(Backgrd);
		lblBackgroundImageM.setForeground(new Color(0, 0, 204));
		lblBackgroundImageM.setBounds(0, 0, 944, 537);
		panelMain.add(lblBackgroundImageM);
		
		// ************************** CIRCLE SCREEN *************************************
		
		JLabel lblCHeading = new JLabel("**** SHAPE CALCULATOR ****");
		lblCHeading.setForeground(new Color(0, 0, 255));
		lblCHeading.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblCHeading.setBounds(307, 75, 322, 20);
		panelCircle.add(lblCHeading);
		
		JLabel lblDirectC = new JLabel("Please enter the following information (in feet):");
		lblDirectC.setForeground(new Color(0, 0, 255));
		lblDirectC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectC.setBounds(139, 152, 485, 20);
		panelCircle.add(lblDirectC);
		
		JLabel lblImageC = new JLabel(" ");
		lblImageC.setBounds(672, 123, 201, 175);
		lblImageC.setIcon(new ImageIcon("C:/Users/marga/workspace/CalculateShapes/src/circle.gif")); 
		panelCircle.add(lblImageC);
		
		JLabel lblRadiusC = new JLabel("Circle Radius:");
		lblRadiusC.setForeground(new Color(0, 0, 255));
		lblRadiusC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRadiusC.setBounds(335, 210, 137, 20);
		panelCircle.add(lblRadiusC);
		
		JLabel lblResponseC = new JLabel("The area of the circle in sq. ft. is:");
		lblResponseC.setForeground(new Color(0, 0, 255));
		lblResponseC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseC.setBounds(166, 266, 306, 20);
		panelCircle.add(lblResponseC);
		
		txtFldRadiusC = new JTextField();
		txtFldRadiusC.setForeground(Color.BLUE);
		txtFldRadiusC.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldRadiusC.setColumns(10);
		txtFldRadiusC.setBounds(483, 210, 146, 26);
		txtFldRadiusC.setCaretPosition(0);
		panelCircle.add(txtFldRadiusC);
		
		JLabel lblAreaC = new JLabel(" ");
		lblAreaC.setBackground(new Color(255, 255, 255));
		lblAreaC.setForeground(new Color(204, 0, 0));
		lblAreaC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAreaC.setBounds(483, 265, 146, 23);
		panelCircle.add(lblAreaC);
		
		JLabel lblResponse2C = new JLabel("The volume of the circle in cubic ft. is:");
		lblResponse2C.setForeground(Color.BLUE);
		lblResponse2C.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponse2C.setBounds(116, 305, 348, 20);
		panelCircle.add(lblResponse2C);
		
		JLabel lblVolC = new JLabel(" ");
		lblVolC.setForeground(new Color(204, 0, 0));
		lblVolC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblVolC.setBackground(Color.WHITE);
		lblVolC.setBounds(483, 302, 146, 26);
		panelCircle.add(lblVolC); 
		
		JLabel lblErrMsgC = new JLabel(" ");
		lblErrMsgC.setForeground(new Color(204, 0, 0));
		lblErrMsgC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgC.setBounds(35, 433, 838, 20);
		panelCircle.add(lblErrMsgC);
				
		
		JButton btnCContinue = new JButton("Continue");
		btnCContinue.setForeground(Color.WHITE);
		btnCContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnCContinue.setBackground(new Color(0, 102, 0));
		btnCContinue.setBounds(283, 388, 135, 29);
		panelCircle.add(btnCContinue);
		btnCContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try
				{
					radius = Double.parseDouble(txtFldRadiusC.getText());
						if (radius > 0)
						{	
							 circleObj.setCircleVar(radius);
							 areaRnd = circleObj.getArea();
							 volumeRnd = circleObj.getVolume();
						     lblAreaC.setText(String.format("%,.2f", areaRnd));
						     lblVolC.setText(String.format("%,.2f", volumeRnd));
						     // String areaString = Double.toString(areaRnd);
						     // lblAreaC.setText(areaString);
						     lblErrMsgC.setText(null);
						}     
						else
						{	
							lblAreaC.setText(null);
							lblVolC.setText(null);
							lblErrMsgC.setText("Invalid entry, radius must be greater than 0");
						} 
				}
				   catch(NumberFormatException e1)
				{
				   	lblAreaC.setText(null);
				   	lblVolC.setText(null);
				   	lblErrMsgC.setText("Invalid entry, radius must be a numeric value");
				}
							
			}  // End of Circle Action Performed
			
		}); // End of Circle Continue Button 
		
		
		JButton btnCCancel = new JButton("Return");
		btnCCancel.setForeground(Color.WHITE);
		btnCCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnCCancel.setBackground(new Color(204, 0, 0));
		btnCCancel.setBounds(519, 388, 135, 29);
		panelCircle.add(btnCCancel);
		btnCCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgC.setText(null);
				lblAreaC.setText(null);
				lblVolC.setText(null);
				txtFldRadiusC.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCircle.setVisible(false);
				panelSquare.setVisible(false);
				panelRectangle.setVisible(false);
				panelTriangle.setVisible(false);
			}   // End of Circle Action Performed
			
		});  // End of Circle Cancel Button
		
		
		
		
		JLabel lblBackgroundImageC = new JLabel(Backgrd);
		lblBackgroundImageC.setForeground(new Color(0, 0, 204));
		lblBackgroundImageC.setBounds(0, 0, 944, 537);
		panelCircle.add(lblBackgroundImageC);
		
				
		// ************************** SQUARE SCREEN *************************************
					
		JLabel lblSHeading = new JLabel("**** SHAPE CALCULATOR ****");
		lblSHeading.setForeground(new Color(0, 0, 255));
		lblSHeading.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblSHeading.setBounds(307, 75, 322, 20);
		panelSquare.add(lblSHeading);
		
		JLabel lblImageS = new JLabel(" ");
		lblImageS.setBounds(688, 128, 172, 155);
		lblImageS.setIcon(new ImageIcon("C:/Users/marga/workspace/CalculateShapes/src/square.gif")); 
		panelSquare.add(lblImageS);
		
		JLabel lblDirectS = new JLabel("Please enter the following information (in feet):");
		lblDirectS.setForeground(new Color(0, 0, 255));
		lblDirectS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectS.setBounds(106, 149, 451, 20);
		panelSquare.add(lblDirectS);
		
		JLabel lblSideS = new JLabel("Side Length:");
		lblSideS.setForeground(new Color(0, 0, 255));
		lblSideS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSideS.setBounds(331, 207, 137, 20);
		panelSquare.add(lblSideS);
				
		txtFldSideS = new JTextField();
		txtFldSideS.setForeground(Color.BLUE);
		txtFldSideS.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldSideS.setColumns(10);
		txtFldSideS.setBounds(483, 204, 146, 26);
		txtFldSideS.setCaretPosition(0);
		panelSquare.add(txtFldSideS);
		
		JLabel lblResponseS = new JLabel("The area of the square in sq. ft. is:");
		lblResponseS.setForeground(new Color(0, 0, 255));
		lblResponseS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseS.setBounds(133, 263, 320, 20);
		panelSquare.add(lblResponseS);
				
		JLabel lblAreaS = new JLabel(" ");
		lblAreaS.setBackground(new Color(255, 255, 255));
		lblAreaS.setForeground(new Color(204, 0, 0));
		lblAreaS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAreaS.setBounds(483, 263, 146, 20);
		panelSquare.add(lblAreaS);
		
		JLabel lblResponse2S = new JLabel("The volume of the square in cubic ft. is:");
		lblResponse2S.setForeground(Color.BLUE);
		lblResponse2S.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponse2S.setBounds(88, 300, 356, 20);
		panelSquare.add(lblResponse2S);
		
		JLabel lblVolS = new JLabel(" ");
		lblVolS.setForeground(new Color(204, 0, 0));
		lblVolS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblVolS.setBackground(Color.WHITE);
		lblVolS.setBounds(486, 300, 146, 20);
		panelSquare.add(lblVolS);
		
		JLabel lblErrMsgS = new JLabel(" ");
		lblErrMsgS.setForeground(new Color(204, 0, 0));
		lblErrMsgS.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgS.setBounds(35, 433, 838, 20);
		panelSquare.add(lblErrMsgS);
		
				
		JButton btnSContinue = new JButton("Continue");
		btnSContinue.setForeground(Color.WHITE);
		btnSContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSContinue.setBackground(new Color(0, 102, 0));
		btnSContinue.setBounds(283, 388, 135, 29);
		panelSquare.add(btnSContinue);
		btnSContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					side = Double.parseDouble(txtFldSideS.getText());
						if (side > 0)
						{	
							 squareObj.setSquareVar(side);
							 areaRnd = squareObj.getArea();
							 volumeRnd = squareObj.getVolume();
						     lblAreaS.setText(String.format("%,.2f", areaRnd));
						     lblVolS.setText(String.format("%,.2f", volumeRnd));
						     // String areaString = Double.toString(areaRnd);
						     // lblAreaC.setText(areaString);
						     lblErrMsgS.setText(null);
						}     
						else
						{	
							lblAreaS.setText(null);
							lblVolS.setText(null);
							lblErrMsgS.setText("Invalid entry, side must be greater than 0");
						} 
				}
				   catch(NumberFormatException e1)
				{
				   	lblAreaS.setText(null);
				   	lblVolS.setText(null);
				   	lblErrMsgS.setText("Invalid entry, side must be a numeric value");
				}
							
			}  // End of Square Action Performed
			
		}); // End of Square Continue Button 
				
				
		JButton btnSCancel = new JButton("Return");
		btnSCancel.setForeground(Color.WHITE);
		btnSCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSCancel.setBackground(new Color(204, 0, 0));
		btnSCancel.setBounds(519, 388, 135, 29);
		panelSquare.add(btnSCancel);
		btnSCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgS.setText(null);
				lblAreaS.setText(null);
				lblVolS.setText(null);
				lblSideS.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCircle.setVisible(false);
				panelSquare.setVisible(false);
				panelRectangle.setVisible(false);
				panelTriangle.setVisible(false);
			}   // End of Rectangle Action Performed
		}); // End of Action Performed
		
		
		JLabel lblBackgroundImageS = new JLabel(Backgrd);
		lblBackgroundImageS.setForeground(new Color(0, 0, 204));
		lblBackgroundImageS.setBounds(0, 0, 944, 537);
		panelSquare.add(lblBackgroundImageS);

		// ********************** RECTANGLE SCREEN *************************************
				
		JLabel lblRHeading = new JLabel("**** SHAPE CALCULATOR ****");
		lblRHeading.setForeground(new Color(0, 0, 255));
		lblRHeading.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblRHeading.setBounds(307, 75, 322, 20);
		panelRectangle.add(lblRHeading);
		
		JLabel lblImageR = new JLabel(" ");
		lblImageR.setBounds(664, 129, 209, 134);
		lblImageR.setIcon(new ImageIcon("C:/Users/marga/workspace/CalculateShapes/src/rectangle.gif")); 
		panelRectangle.add(lblImageR);
		
		JLabel lblDirectR = new JLabel("Please enter the following information (in feet):");
		lblDirectR.setForeground(Color.BLUE);
		lblDirectR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectR.setBounds(126, 112, 453, 20);
		panelRectangle.add(lblDirectR);
		
		JLabel lblLengthR = new JLabel("Rectangle Length:");
		lblLengthR.setForeground(Color.BLUE);
		lblLengthR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLengthR.setBounds(273, 164, 172, 20);
		panelRectangle.add(lblLengthR);
		
		txtFldLengthR = new JTextField();
		txtFldLengthR.setForeground(Color.BLUE);
		txtFldLengthR.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldLengthR.setColumns(10);
		txtFldLengthR.setBounds(483, 164, 146, 26);
		txtFldLengthR.setCaretPosition(0);
		panelRectangle.add(txtFldLengthR);
		
		JLabel lblWidthR = new JLabel("Rectangle Width:");
		lblWidthR.setForeground(Color.BLUE);
		lblWidthR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblWidthR.setBounds(283, 200, 167, 20);
		panelRectangle.add(lblWidthR);
		
		txtFldWidthR = new JTextField();
		txtFldWidthR.setForeground(Color.BLUE);
		txtFldWidthR.setFont(new Font("Verdana", Font.BOLD, 16));
		txtFldWidthR.setColumns(10);
		txtFldWidthR.setBounds(483, 200, 146, 26);
		panelRectangle.add(txtFldWidthR);
		
		JLabel lblRectangleHeight = new JLabel("Rectangle Height:");
		lblRectangleHeight.setForeground(Color.BLUE);
		lblRectangleHeight.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRectangleHeight.setBounds(273, 236, 167, 20);
		panelRectangle.add(lblRectangleHeight);
		
		txtFldHeightR = new JTextField();
		txtFldHeightR.setForeground(Color.BLUE);
		txtFldHeightR.setFont(new Font("Verdana", Font.BOLD, 16));
		txtFldHeightR.setColumns(10);
		txtFldHeightR.setBounds(483, 236, 146, 26);
		panelRectangle.add(txtFldHeightR);
		
		JLabel lblResponseR = new JLabel("The area of the rectangle in sq. ft. is:");
		lblResponseR.setForeground(Color.BLUE);
		lblResponseR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseR.setBounds(107, 292, 340, 20);
		panelRectangle.add(lblResponseR);
		
		JLabel lblAreaR = new JLabel(" ");
		lblAreaR.setForeground(new Color(204, 0, 0));
		lblAreaR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAreaR.setBackground(Color.WHITE);
		lblAreaR.setBounds(477, 292, 146, 20);
		panelRectangle.add(lblAreaR);
		
		JLabel lblResponse2 = new JLabel("The volume of the rectangle in cubic ft. is:");
		lblResponse2.setForeground(Color.BLUE);
		lblResponse2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponse2.setBounds(62, 328, 384, 20);
		panelRectangle.add(lblResponse2);
		
		JLabel lblVolR = new JLabel(" ");
		lblVolR.setForeground(new Color(204, 0, 0));
		lblVolR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblVolR.setBackground(Color.WHITE);
		lblVolR.setBounds(483, 328, 146, 20);
		panelRectangle.add(lblVolR);
		
		JLabel lblErrMsgR = new JLabel(" ");
		lblErrMsgR.setForeground(new Color(204, 0, 0));
		lblErrMsgR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgR.setBounds(35, 433, 838, 20);
		panelRectangle.add(lblErrMsgR);
		
		JButton btnRContinue = new JButton("Continue");
		btnRContinue.setForeground(Color.WHITE);
		btnRContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRContinue.setBackground(new Color(0, 102, 0));
		btnRContinue.setBounds(283, 388, 135, 29);
		panelRectangle.add(btnRContinue);
		btnRContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					width = Double.parseDouble(txtFldWidthR.getText());
					length = Double.parseDouble(txtFldLengthR.getText());
					height = Double.parseDouble(txtFldHeightR.getText());
						if ((width > 0) && (length > 0) && (height > 0))
						{	 
							   
							 rectangleObj.setRectangleVar(length, width, height);
							 areaRnd = rectangleObj.getArea();
							 volumeRnd = rectangleObj.getVolume();
						     lblAreaR.setText(String.format("%,.2f", areaRnd));
						     lblVolR.setText(String.format("%,.2f", volumeRnd));
						     lblErrMsgR.setText(null);
						}     
						else
						{	
							 lblAreaR.setText(null);
							 lblVolR.setText(null);
							 lblErrMsgR.setText("Invalid entry, length, width and height must all be greater than 0");
						}
				}
			    catch(NumberFormatException e1)
				{
			    	lblAreaR.setText(null);
			    	lblVolR.setText(null);
			    	lblErrMsgR.setText("Invalid entry, length, width and height must all be a numeric value");
			    }
			}
		});
				
				
		JButton btnRCancel = new JButton("Return");
		btnRCancel.setForeground(Color.WHITE);
		btnRCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRCancel.setBackground(new Color(204, 0, 0));
		btnRCancel.setBounds(519, 388, 135, 29);
		panelRectangle.add(btnRCancel);
		btnRCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgR.setText(null);
				lblAreaR.setText(null);
				lblVolR.setText(null);
				txtFldLengthR.setText(null);
				txtFldWidthR.setText(null);
				txtFldHeightR.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCircle.setVisible(false);
				panelSquare.setVisible(false);
				panelRectangle.setVisible(false);
				panelTriangle.setVisible(false);
			}   // End of Rectangle Action Performed
		}); // End of Action Performed
		
		
		JLabel lblBackgroundImageR = new JLabel(Backgrd);
		lblBackgroundImageR.setForeground(new Color(0, 0, 204));
		lblBackgroundImageR.setBounds(0, 0, 944, 537);
		panelRectangle.add(lblBackgroundImageR);
		
		
		
		// *********************** TRIANGLE SCREEN *************************************
				
		JLabel lblTHeading = new JLabel("**** SHAPE CALCULATOR ****");
		lblTHeading.setForeground(new Color(0, 0, 255));
		lblTHeading.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTHeading.setBounds(307, 75, 322, 20);
		panelTriangle.add(lblTHeading);
		
		JLabel lblImageT = new JLabel(" ");
		lblImageT.setBounds(681, 119, 181, 175);
		lblImageT.setIcon(new ImageIcon("C:/Users/marga/workspace/CalculateShapes/src/triangle.gif")); 
		panelTriangle.add(lblImageT);
		
		JLabel lblDirectT = new JLabel("Please enter the following information (in feet):");
		lblDirectT.setForeground(Color.BLUE);
		lblDirectT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectT.setBounds(80, 119, 433, 20);
		panelTriangle.add(lblDirectT);
		
		JLabel lblBaseT = new JLabel("Triangle Base:");
		lblBaseT.setForeground(Color.BLUE);
		lblBaseT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBaseT.setBounds(295, 172, 146, 20);
		panelTriangle.add(lblBaseT);
		
		txtFldBaseT = new JTextField();
		txtFldBaseT.setForeground(Color.BLUE);
		txtFldBaseT.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldBaseT.setColumns(10);
		txtFldBaseT.setBounds(481, 172, 146, 26);
		txtFldBaseT.setCaretPosition(0);
		panelTriangle.add(txtFldBaseT);
		
		JLabel lblHeightT = new JLabel("Triangle Height:");
		lblHeightT.setForeground(Color.BLUE);
		lblHeightT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblHeightT.setBounds(282, 208, 162, 20);
		panelTriangle.add(lblHeightT);
		
		txtFldHeightT = new JTextField();
		txtFldHeightT.setForeground(Color.BLUE);
		txtFldHeightT.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldHeightT.setColumns(10);
		txtFldHeightT.setBounds(481, 208, 146, 26);
		panelTriangle.add(txtFldHeightT);
		
		JLabel lblLengthT = new JLabel("Triangle Length:");
		lblLengthT.setForeground(Color.BLUE);
		lblLengthT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLengthT.setBounds(282, 244, 162, 20);
		panelTriangle.add(lblLengthT);
		
		txtFldLengthT = new JTextField();
		txtFldLengthT.setForeground(Color.BLUE);
		txtFldLengthT.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtFldLengthT.setColumns(10);
		txtFldLengthT.setBounds(481, 244, 146, 26);
		panelTriangle.add(txtFldLengthT);
		
		JLabel lblResponseT = new JLabel("The area of the triangle in sq. ft. is:");
		lblResponseT.setForeground(Color.BLUE);
		lblResponseT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseT.setBounds(107, 290, 328, 20);
		panelTriangle.add(lblResponseT);
		
		JLabel lblAreaT = new JLabel(" ");
		lblAreaT.setForeground(new Color(204, 0, 0));
		lblAreaT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAreaT.setBackground(Color.WHITE);
		lblAreaT.setBounds(481, 293, 146, 20);
		panelTriangle.add(lblAreaT);
		
		JLabel lblResponse2T = new JLabel("The volume of the triangle in cubic ft. is:");
		lblResponse2T.setForeground(Color.BLUE);
		lblResponse2T.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponse2T.setBounds(58, 326, 364, 20);
		panelTriangle.add(lblResponse2T);
		
		JLabel lblVolT = new JLabel(" ");
		lblVolT.setForeground(new Color(204, 0, 0));
		lblVolT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblVolT.setBackground(Color.WHITE);
		lblVolT.setBounds(485, 329, 146, 20);
		panelTriangle.add(lblVolT);
		
		JLabel lblErrMsgT = new JLabel(" ");
		lblErrMsgT.setForeground(new Color(204, 0, 0));
		lblErrMsgT.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgT.setBounds(35, 433, 838, 20);
		panelTriangle.add(lblErrMsgT);
				
		JButton btnTContinue = new JButton("Continue");
		btnTContinue.setForeground(Color.WHITE);
		btnTContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnTContinue.setBackground(new Color(0, 102, 0));
		btnTContinue.setBounds(283, 388, 135, 29);
		panelTriangle.add(btnTContinue);
		btnTContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					base = Double.parseDouble(txtFldBaseT.getText());
					length = Double.parseDouble(txtFldLengthT.getText());
					height = Double.parseDouble(txtFldHeightT.getText());
						if ((base > 0) && (length > 0) && (height > 0))
						{	 
							   
							 triangleObj.setTriangleVar(base, height, length);
							 areaRnd = triangleObj.getArea();
							 volumeRnd = triangleObj.getVolume();
						     lblAreaT.setText(String.format("%,.2f", areaRnd));
						     lblVolT.setText(String.format("%,.2f", volumeRnd));
						     lblErrMsgR.setText(null);
						}     
						else
						{	
							 lblAreaT.setText(null);
							 lblVolT.setText(null);
							 lblErrMsgT.setText("Invalid entry, length, base and height must all be greater than 0");
						}
				}
			    catch(NumberFormatException e1)
				{
			    	lblAreaT.setText(null);
			    	lblVolT.setText(null);
			    	lblErrMsgT.setText("Invalid entry, length, base and height must all be a numeric value");
			    }
			}
		});
		
		
		JButton btnTCancel = new JButton("Return");
		btnTCancel.setForeground(Color.WHITE);
		btnTCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnTCancel.setBackground(new Color(204, 0, 0));
		btnTCancel.setBounds(519, 388, 135, 29);
		panelTriangle.add(btnTCancel);
		btnTCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgT.setText(null);
				lblAreaT.setText(null);
				lblVolT.setText(null);
				txtFldLengthT.setText(null);
				txtFldBaseT.setText(null);
				txtFldHeightT.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCircle.setVisible(false);
				panelSquare.setVisible(false);
				panelRectangle.setVisible(false);
				panelTriangle.setVisible(false);
			}   // End of Rectangle Action Performed
		}); // End of Action Performed
				
				
		JLabel lblBackgroundImageT = new JLabel(Backgrd);
		lblBackgroundImageT.setForeground(new Color(0, 0, 204));
		lblBackgroundImageT.setBounds(0, 0, 944, 537);
		panelTriangle.add(lblBackgroundImageT);
		
		
		
	}  // END OF INITIALIZE
	
} // END OF CLASS CALCULATE SHAPES
