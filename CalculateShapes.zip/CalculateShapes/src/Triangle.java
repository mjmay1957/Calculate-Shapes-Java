
public class Triangle extends Shape 
{

static String sName;
	
	static double volume;
	static double area;
	static double base;
	static double height;
	static double length;
	static double areaRnd;
	static double volumeRnd;
	
	
	// Constructor
	public Triangle(String sn) 
	{
		super(sn);
		sName=sn;
	}
	
	public void setshapeName(String sn)
	{
		sName = sn;
	}

	
	
	// Set the base and height to be used in Triangle class from the base and height entered on screen
	public void setTriangleVar(double b, double h, double l)
	{
		base = b;
		height = h;
		length = l;
	}
	
				
	// Triangle Method accepts base and height of a triangle and returns the area  
	public double getArea()
	{ 
		area = .5 * base * height;
		areaRnd = Math.round(area * 100)/ 100.0;
	
		return areaRnd;
	}


	// Rectangle Method accepts base, height and length of a triangle and returns the volume  
	public double getVolume() 
	{
		volume = ((height * base) / 2) * length;
		volumeRnd = Math.round(volume * 100)/ 100.0;
		
	    return volumeRnd;
	}
	
	
}
