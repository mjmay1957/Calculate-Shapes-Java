
public class Circle extends Shape 
{

	private String sName;
	private double piCalc;
	private double volume;
	private double area;
	private double radius;
	double areaRnd = 0;
	double volumeRnd = 0;	
	
	
	// Constructor
	public Circle(String sn) 
	{
		super(sn);
		sName=sn;
	}
	
	public void setshapeName(String sn)
	{
		sName = sn;
	}
	
	// Set the radius to be used in Circle class from the radius entered on screen
		public void setCircleVar(double r)
		{
			radius = r;
		}

	@Override
	public double getArea() {
		piCalc = (double) Math.PI ;
		area = piCalc * (radius * radius);
		areaRnd = Math.round(area * 100)/ 100.0; 
		return areaRnd;
	}

	@Override
	public double getVolume() {
		piCalc = (double) Math.PI ;
		volume = 1.33333333333 * piCalc * radius * radius * radius;
		volumeRnd = Math.round(volume * 100)/ 100.0;
		return volumeRnd;
	}
		
		
	
}
