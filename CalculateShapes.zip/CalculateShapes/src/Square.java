
public class Square extends Shape 
{
static String sName;
	
	static double volume;
	static double area;
	static double side;
	static double areaRnd;
	static double volumeRnd;
	
	
	// Constructor
	public Square(String sn) 
	{
		super(sn);
		sName=sn;
	}
	
	public void setshapeName(String sn)
	{
		sName = sn;
	}

	
	
	// Set the side to be used in Square class from the side entered on screen
	public void setSquareVar(double s)
	{
		side = s;
	}
	
				
	// Square Method accepts side of a square and returns the area  
	public double getArea()
	{ 
		area = (side * side);
		areaRnd = Math.round(area * 100)/ 100.0;
	
	return areaRnd;
	}


	// Square Method accepts side of a square and returns the volume  
	public double getVolume() 
	{
		volume = (side * side * side);
		volumeRnd = Math.round(volume * 100)/ 100.0;
		
	return volumeRnd;
	}
	
	
}
